# DOTS-Android

A native Android WebView shell for the DOTS assistant website.

## Build APK using GitHub Actions
1. Upload these project files to the repository, preserving their folder paths.
2. Open the repository's **Actions** tab.
3. Select **Build DOTS Android APK** and tap **Run workflow** (or push a commit to `main`).
4. When the workflow succeeds, open the run and download the `DOTS-debug-APK` artifact.

## Current scope
- Native Android app shell loading the DOTS web assistant.
- Internet and runtime microphone permission handling for web audio requests.
- Automatic debug APK build via GitHub Actions.

## Limitations
This first version does not implement an always-on “Hey DOTS” wake word or a floating overlay. Android background microphone use has OS/device restrictions; these features require separate implementation and real-device testing. A successful CI build is not proof that every feature works on every phone. Internet is required to load the web assistant.
